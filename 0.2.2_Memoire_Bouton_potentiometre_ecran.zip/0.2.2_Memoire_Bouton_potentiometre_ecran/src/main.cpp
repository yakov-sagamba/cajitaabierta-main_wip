#include <Arduino.h>
#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <LittleFS.h> // Pour écrire sur la mémoire Flash

// Définition des broches
const int buttonPin = 0;    // Broche à laquelle le bouton est connecté
const int ledPin = 2;       // Broche à laquelle la LED est connectée (LED intégrée sur GPIO 2)

// Variables
int buttonState = 0;        // Variable pour lire l'état du bouton
const int seuil = 1000;   // Threshold 1000ms = 1 second long press
unsigned long pressStartTime = 0;
bool buttonPressed = false;
int pot1 = 0;
int pot2 = 0;

int compteur = 0; // compte le nombre de fois que nous exécutons la boucle
const int nombreLectures = 100;    // nombre de lectures
int lectures[nombreLectures];      // tableau pour contenir les données

///////// DISPLAY ////////
#define SCREEN_WIDTH 128 // OLED display width, in pixels
#define SCREEN_HEIGHT 64 // OLED display height, in pixels
#define OLED_SDA_PIN 21
#define OLED_SCL_PIN 22
#define OLED_RESET     -1 // Reset pin # (or -1 if sharing Arduino reset pin)
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
//////////////////////////

///// Enregistrer les données dans la mémoire /////
void enregistrerDonnees(){
  File file = LittleFS.open("/lectures.txt", "w"); // Overwrite the file

  if (!file) {
    Serial.println("Je n'ai pas pu ouvrir le fichier pour écrire");
  } else {
    for (int i = 0; i < nombreLectures; i++) {
      file.println(lectures[i]); // Or use CSV: file.print(...), file.print(",")
      delay(50); // optional delay
    }
    file.close();
    Serial.println("Les données sont enregistrées dans /lectures.txt");
  }
}

void lireDonnees(){
    File file = LittleFS.open("/lectures.txt", "r");
    if (!file) {
      Serial.println("Le fishier /lectures.txt n'a pu être ouvert");
      return;
    }
  
    Serial.println("Contenu du fichier:");
    while (file.available()) {
      String line = file.readStringUntil('\n');
      Serial.println(line);
    }
  
    file.close();  
}

void setup() {
  Serial.begin(115200);
  ///////////// DISPLAY /////////////  
  Wire.begin(OLED_SDA_PIN, OLED_SCL_PIN);
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println(F("SSD1306 allocation failed"));
    for (;;); // Don't proceed, loop forever
  }


  if (!LittleFS.begin()) {
    Serial.println("LittleFS mount failed. Formatting...");
    // Optional: format the file system
    LittleFS.format();
    if (!LittleFS.begin()) {
      Serial.println("LittleFS mount failed after format.");
      return;
    }
  }

  Serial.println("LittleFS mounted successfully.");

  // Affiche 'Cajita Abierta'
  display.clearDisplay();
  display.setTextSize(1);             
  display.setTextColor(WHITE);        
  display.setCursor(0, 0); // Coordonnées d'affichage du texte
  display.print(F("Cajita Abierta v0.9"));
  display.display();
  delay(2000); // Pause de 2 secondes

  // Initialisation de la LED comme sortie
  pinMode(ledPin, OUTPUT);

  // Initialisation du bouton comme entrée avec un pullup interne
  pinMode(buttonPin, INPUT_PULLUP);

  // Assurez-vous que la LED est éteinte au démarrage
  digitalWrite(ledPin, LOW);

}

void loop() {
  display.clearDisplay();
  display.setTextSize(1);             
  display.setTextColor(WHITE);       
  display.setCursor(0, 0);
  display.print(F("Cajita Abierta v0.9"));
  display.setTextSize(2);
  display.setTextColor(WHITE);
  
  // Lire l'état du bouton
  buttonState = digitalRead(buttonPin);

  if (buttonState == LOW && !buttonPressed) {
    pressStartTime = millis();
    buttonPressed = true;
  }
  if (buttonState == HIGH && buttonPressed) {
    unsigned long pressDuration = millis() - pressStartTime;
    buttonPressed = false;

    if (pressDuration < seuil) {
      Serial.println("Courte pression : Écriture des données");
      enregistrerDonnees();
    } else {
      Serial.println("Longue pression : Lecture des données");
      lireDonnees();
    }
  }


  /*

  // Si le bouton est pressé (LOW), allumer la LED
  if (buttonState == LOW) {
    //digitalWrite(ledPin, HIGH);
    Serial.println("DEL allumée"); 
    enregistrerDonnees();
  } 
  // Sinon, éteindre la LED
  else {
    //digitalWrite(ledPin, LOW);
    //Serial.println("DEL éteinte"); 
  }
    */

    pot1 = analogRead(25);
    lectures[compteur] = pot1; 

    pot2 = analogRead(26);
    //pot1 = map(pot1,0,4095,0,255);
    //pot2 = map(pot2,0,4095,0,255);
    Serial.println(pot1);
    //Serial.println(pot2);
    display.setCursor(0, 26);
    display.println(pot1);
    display.setCursor(60, 26);
    display.println(pot2);
    display.display();


  delay(100);
  //Serial.print("compteur : ");
  //Serial.println(compteur);
  compteur = compteur + 1; // augmente de '1' la valeur de compteur à chaque passage dans la boucle

  if (compteur >= nombreLectures){
    compteur = 0; // remise à '0' si compteur est plus grand que le nombre de lectures.
  }

}